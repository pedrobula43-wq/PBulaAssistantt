# PBulaAssistantt

Projeto Flutter do aplicativo PBulaAssistantt.

## Estrutura
- `lib/main.dart` — código principal da aplicação
- `assets/pbula_logo.jpg` — logótipo
- `pubspec.yaml` — configuração Flutter
- `.github/workflows/build-apk.yml` — compilação automática do APK

## Gerar APK
No GitHub, abra **Actions**, selecione **Build PBulaAssistantt APK** e use **Run workflow**.  
Quando terminar com ✓ verde, abra a execução e descarregue o artefacto **PBulaAssistantt-APK**.
